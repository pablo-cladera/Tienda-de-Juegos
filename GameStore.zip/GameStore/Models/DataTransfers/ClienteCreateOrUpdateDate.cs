﻿namespace GameStore.Models.DataTransfers
{
    public class ClienteCreateOrUpdateDate
    {
            public decimal Id { get; set; }
            public decimal IdPersona { get; set; }

    }
}
