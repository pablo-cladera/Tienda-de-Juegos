﻿namespace GameStore.Models.DataTransfers
{
    public class JuegoLiteDTO
    {
        public string? Nombre { get; set; }
    }
}
