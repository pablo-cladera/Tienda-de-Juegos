﻿namespace GameStore.Models.DataTransfers
{
    public class ClienteViewModel
    {
        public Persona IdPersona { get; set; }


    }
}
